package com.facom.SGCteam01.SGCTeam01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgcTeam01Application {

	public static void main(String[] args) {
		SpringApplication.run(SgcTeam01Application.class, args);
	}
}
